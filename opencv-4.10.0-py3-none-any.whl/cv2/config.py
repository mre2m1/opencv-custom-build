import os

BINARIES_PATHS = [
    'C:/Users/e2mre/source/repos/opencv/build/bin/Release'
] + BINARIES_PATHS
